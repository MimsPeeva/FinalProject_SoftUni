﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Recipify.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Recipify.GCommon.ValidationConstants.Comment;
namespace Recipify.Data.Configuration
{
    public class CommentConfiguration:IEntityTypeConfiguration<Comment>
    {
        public void Configure(EntityTypeBuilder<Comment> builder)
        {
            builder.Property(c => c.Content)
                .IsRequired()
                .HasMaxLength(CommentContentMaxLength);

            builder.Property(c => c.Author)
                .IsRequired()
                .HasMaxLength(CommentAuthorMaxLength);

            builder.HasOne(c => c.Recipe)
                .WithMany(r => r.Coments)
                .HasForeignKey(c => c.RecipeId);
        }

        
    }
}
