﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Recipify.Data.Models;
using Recipify.GCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Recipify.GCommon.ValidationConstants.Recipe;
namespace Recipify.Data.Configuration
{
    public class RecipeConfiguration : IEntityTypeConfiguration<Recipe>
    {
        public void Configure(EntityTypeBuilder<Recipe> builder)
        {
            builder.Property(r => r.Title)
             .IsRequired()
             .HasMaxLength(RecipeTitleMaxLength);

            builder.Property(r => r.Description)
                             .IsRequired()
                .HasMaxLength(RecipeDescriptionMaxLength);

            builder.Property(r => r.Instructions)
                .IsRequired()
                .HasMaxLength(RecipeInstructionsMaxLength);

            builder.Property(e => e.ImageUrl)
           .IsRequired(false);

            builder.HasOne(r => r.Category)
                .WithMany(c => c.Recipes)
                .HasForeignKey(r => r.CategoryId);

            builder.HasOne(r => r.Difficulty)
                .WithMany(d => d.Recipes)
                .HasForeignKey(r => r.DifficultyId);

            builder.HasOne(r => r.Cuisine)
                .WithMany(c => c.Recipes)
                .HasForeignKey(r => r.CuisineId);
        }
    }
}
