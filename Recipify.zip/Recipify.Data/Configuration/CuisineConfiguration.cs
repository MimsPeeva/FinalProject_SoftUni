﻿using Microsoft.EntityFrameworkCore;
using Recipify.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Recipify.GCommon.ValidationConstants.Cuisine;
namespace Recipify.Data.Configuration
{
    public class CuisineConfiguration:IEntityTypeConfiguration<Cuisine>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<Cuisine> builder)
        {
            builder.HasKey(c => c.Id);

            builder.Property(c => c.Name)
                .IsRequired()
                .HasMaxLength(CuisineNameMaxLength);
        }
  
    }
}
